#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 16 16:26:15 2018

@author: ghh
"""

import pickle


def loadpkfile(filename):
    f = open(filename,'rb')
    data = pickle.load(f)
    f.close()
#    for i in data.keys():
#        globals()[i] = data[i]
    return data

def savepkfile(filename,data):
    pkfile = open(filename,'wb')
    pickle.dump(data,pkfile)
    pkfile.close()

def __init__():
    return globals()