#!/usr/bin/env python
# coding: utf-8




import struct
import warnings

import cartopy.crs as ccrs
import cartopy.feature as feature
import matplotlib as mpl
import matplotlib.pylab as plt
import numpy as np
import scipy.ndimage as si
import scipy.signal as sg
import xarray as xr
from band.lineartrend import callt
from cartopy.mpl.ticker import LatitudeFormatter, LongitudeFormatter
from loadbin import loadpkfile, savepkfile
from matplotlib import cm, colors
from scipy.io import loadmat

warnings.filterwarnings("ignore")
import matplotlib.ticker as mticker

formatter = mticker.ScalarFormatter(useOffset=False, useMathText=True)
formatter.set_powerlimits((-3, 2))




# broostrap code
def bequ(data):
    n_iterations = 2000
    sample_size = len(data)
    bootstrap_means = []
    for _ in range(n_iterations):
        bootstrap_sample = np.random.choice(data, size=sample_size, replace=True)
        bootstrap_mean = np.mean(bootstrap_sample)
        bootstrap_means.append(bootstrap_mean)
        confidence_interval = np.percentile(bootstrap_means, [2.5, 97.5])
    return confidence_interval




exps = [
    "CESM-iHESP",
    "CESM-TAMU",
    "HadGEM3-GC31-HH1",
    "sHadGEM3-GC31-HM",
    "sHadGEM3-GC31-MM",
    "sCMCC-CM2",
    "CNRM-CM6-1-HR",
    "sEC-Earth3P-HR",
]
wbcs = ["ac", "bc", "ea", "gs", "kc"]
secs = ["ag4", "bc5", "ea4", "gf5", "pn"]

treall = {}
trwall = {}

filename = "data/colormap1.act"

DATA = []
with open(filename, "rb") as actFile:
    for _ in range(256):
        raw = actFile.read(3)
        color = struct.unpack("3B", raw)
        DATA.append(tuple([i / 255 for i in color]))
data1 = DATA[::16]
color = (249, 246, 238)
color = (255, 255, 255)

xx = tuple([i / 255 for i in color])
data1[7] = xx
data1[8] = xx
newcmp = colors.LinearSegmentedColormap.from_list("chaos", data1[:])
newcmp




wbcs = ["ac", "bc", "ea", "gs", "kc"]
secs = ["ag4", "bc5", "ea4", "gf5", "pn"]
time = np.arange(0, 101, 1)
nw = len(wbcs)
ne = len(exps)





lon1all = {
    "kc": 125,
    "gs": -80 + 360,
    "ac": 31,
    "ea": 150,
    "bc": -45 + 360,
}
lon2all = {
    "kc": 131,
    "gs": -74 + 360,
    "ac": 38,
    "ea": 156,
    "bc": -39 + 360,
}
lat1all = {
    "kc": 26,
    "gs": 31,
    "ac": -30,
    "ea": -35,
    "bc": -26,
}
lat2all = {
    "kc": 30,
    "gs": 35,
    "ac": -25.5,
    "ea": -31,
    "bc": -22,
}
levelsall = {
    "kc": np.arange(-1e-2, 1.01e-2, 0.2e-2) * 100,
    "gs": np.arange(-1.5e-2, 1.51e-2, 0.25e-2) * 100,
    "ac": np.arange(-1e-2, 1.01e-2, 0.2e-2) * 100,
    "ea": np.arange(-1.5e-2, 1.51e-2, 0.25e-2) * 100,
    "bc": np.arange(-0.4e-2, 0.41e-2, 0.1e-2) * 100,
}
adtalls = {
    "kc": 90,
    "gs": 0,
    "ac": 40,
    "ea": 45,
    "bc": 15,
}
bars = {
    "kc": np.arange(-1e-2, 1.01e-2, 0.4e-2) * 100,
    "gs": np.arange(-1.5e-2, 1.51e-2, 0.5e-2) * 100,
    "ac": np.arange(-1e-2, 1.01e-2, 0.4e-2) * 100,
    "ea": np.arange(-1.5e-2, 1.51e-2, 0.5e-2) * 100,
    "bc": np.arange(-0.4e-2, 0.41e-2, 0.2e-2) * 100,
}

titles = {
    "kc": "a",
    "gs": "b",
    "ac": "c",
    "ea": "d",
    "bc": "e",
}


lonpall = {}
latpall = {}

wbc = "kc"
lat1 = 27.5
lon1 = 128.25
lat2 = 30.5
lon2 = 124.5
cor = np.polyfit([lon1, lon2], [lat1, lat2], deg=1)
lonp = np.arange(126, 130.01, 0.1)
latp = lonp * cor[0] + cor[1]
lonpall.update({wbc: lonp})
latpall.update({wbc: latp})


wbc = "gs"
lat1 = 30
lat2 = 34
lon1 = -75
lon2 = -79.5
cor = np.polyfit([lon1, lon2], [lat1, lat2], deg=1)
lonp = np.arange(lon2 + 1, -76, 0.1)
latp = lonp * cor[0] + cor[1]
lonpall.update({wbc: lonp})
latpall.update({wbc: latp})

wbc = "ac"
lat1 = -29.5
lon1 = 36.5
lat2 = -26
lon2 = 32
cor = np.polyfit([lon1, lon2], [lat1, lat2], deg=1)
lonp = np.arange(lon2, lon1 + 0.01, 0.1)
latp = lonp * cor[0] + cor[1]
lonpall.update({wbc: lonp})
latpall.update({wbc: latp})

wbc = "ea"

lat0 = -33  # ea4
lon1 = 151
lon2 = 157
lon = np.arange(lon1, lon2 - 2 + 0.01, 0.1)
lonp = lon[:]
latp = np.ones(len(lon)) * lat0

lonpall.update({wbc: lonp})
latpall.update({wbc: latp})

wbc = "bc"
lon1 = -42.5
lon2 = -41

lat1 = -23
lat2 = -26
cor = np.polyfit([lon1, lon2], [lat1, lat2], deg=1)
lonp = np.arange(lon1, lon2 + 0.01, 0.1)
latp = lonp * cor[0] + cor[1]

lonpall.update({wbc: lonp})
latpall.update({wbc: latp})

xticksall = {
    "kc": np.arange(122, lon2all["kc"] + 1, 2),
    "gs": np.arange(lon1all["gs"], lon2all["gs"] + 1, 2),
    "ac": np.arange(32, lon2all["ac"] + 1, 2),
    "ea": np.arange(lon1all["ea"] + 1, lon2all["ea"] + 1, 2),
    "bc": np.arange(316, lon2all["bc"] + 1, 2),
}

yticksall = {
    "kc": np.arange(26, lat2all["kc"] + 1, 1),
    "gs": np.arange(lat1all["gs"], lat2all["gs"] + 1, 1),
    "ac": np.arange(lat1all["ac"], lat2all["ac"] + 1, 1),
    "ea": np.arange(lat1all["ea"], lat2all["ea"] + 1, 1),
    "bc": np.arange(lat1all["bc"], lat2all["bc"] + 1, 1),
}

labelsall = {
    "kc": "Kuroshio Current",
    "gs": "Gulf Stream",
    "ac": "Agulhas Current",
    "ea": " East Australian Current",
    "bc": "Brazil Current",
}




fig = plt.figure(figsize=(11, 7.5))
wbc = "kc"
lon1 = lon1all[wbc]
lon2 = lon2all[wbc]
myproj = ccrs.PlateCarree(central_longitude=(lon1 + lon2) / 2)
ax1 = plt.subplot2grid((10, 6), (0, 1), colspan=2, rowspan=3, projection=myproj)
wbc = "gs"
lon1 = lon1all[wbc]
lon2 = lon2all[wbc]
myproj = ccrs.PlateCarree(central_longitude=(lon1 + lon2) / 2)
ax2 = plt.subplot2grid((10, 6), (0, 3), colspan=2, rowspan=3, projection=myproj)
wbc = "ac"
lon1 = lon1all[wbc]
lon2 = lon2all[wbc]
myproj = ccrs.PlateCarree(central_longitude=(lon1 + lon2) / 2)
ax3 = plt.subplot2grid((10, 6), (3, 0), colspan=2, rowspan=3, projection=myproj)
wbc = "ea"
lon1 = lon1all[wbc]
lon2 = lon2all[wbc]
myproj = ccrs.PlateCarree(central_longitude=(lon1 + lon2) / 2)
ax4 = plt.subplot2grid((10, 6), (3, 2), colspan=2, rowspan=3, projection=myproj)
wbc = "bc"
lon1 = lon1all[wbc]
lon2 = lon2all[wbc]
myproj = ccrs.PlateCarree(central_longitude=(lon1 + lon2) / 2)
ax5 = plt.subplot2grid((10, 6), (3, 4), colspan=2, rowspan=3, projection=myproj)

ax6 = plt.subplot2grid(
    (10, 6),
    (6, 0),
    colspan=6,
    rowspan=4,
)


axall = {
    "kc": ax1,
    "gs": ax2,
    "ac": ax3,
    "ea": ax4,
    "bc": ax5,
}

for iw in range(nw):
    sec = secs[iw]
    wbc = wbcs[iw]
    ax = axall[wbc]

    lon1 = lon1all[wbc]
    lon2 = lon2all[wbc]
    lat1 = lat1all[wbc]
    lat2 = lat2all[wbc]
    dsu = xr.open_dataset('data/' + wbc + "_trend50.nc")
    ds = dsu
    lon = ds.lon
    lat = ds.lat
    crt = (lon >= lon1) & (lon <= lon2) & (lat >= lat1) & (lat <= lat2)
    data = ds.t1.where(crt, drop=True) * 10 * 100
    data2 = ds.p1.where(crt, drop=True)
    temp = data.values
    temp[data2 >= 0.05] = np.nan

    crt = (lon >= lon1) & (lon <= lon2) & (lat >= lat1) & (lat <= lat2)
    dsz = xr.open_dataset("data/esmean_model.nc")
    lon = dsz.lon
    lat = dsz.lat
    crt = (lon >= lon1) & (lon <= lon2) & (lat >= lat1) & (lat <= lat2)
    adt = dsz.SSH.where(crt, drop=True)
    im = data.plot.contourf(
        ax=ax,
        transform=ccrs.PlateCarree(),
        levels=levelsall[wbc],
        extend="both",
        cmap=newcmp,
        add_colorbar=0,
    )
    cbar = plt.colorbar(im, shrink=0.75, pad=0.02, format=formatter)
    # cbar = plt.colorbar(im, shrink=0., pad=0.1, format=formatter,orientation='horizontal')
    cbar.ax.get_yaxis().get_offset_text().set_position((7, 1))
    cbar.set_ticks(bars[wbc])
    cbar.ax.tick_params(axis="y", labelsize=9)

    adt[0, :, :].plot.contour(
        ax=ax,
        transform=ccrs.PlateCarree(),
        levels=[adtalls[wbc]],
        colors="k",
        linewidths=2,
    )

    lonp = lonpall[wbc]
    latp = latpall[wbc]
    ax.plot(lonp, latp, transform=ccrs.PlateCarree(), ls="--", color="k")
    ax.add_feature(feature.LAND, color="gray", zorder=2)
    ax.coastlines(color="k", zorder=2)
    ax.set_xticks(xticksall[wbc], crs=ccrs.PlateCarree())
    ax.set_yticks(yticksall[wbc], crs=ccrs.PlateCarree())
    lon_formatter = LongitudeFormatter(zero_direction_label=False)
    lat_formatter = LatitudeFormatter()
    ax.tick_params(axis="y", labelsize=9)
    ax.tick_params(axis="y", labelsize=9)
    ax.xaxis.set_major_formatter(lon_formatter)
    ax.yaxis.set_major_formatter(lat_formatter)
    ax.set_xlabel("")
    ax.set_ylabel("")
    ax.set_title(labelsall[wbc])
    ax.set_extent([lon1 + 0.125, lon2 - 0.125, lat1 + 0.125, lat2 - 0.125])
    ax.set_title(titles[wbc], loc="left", fontweight="bold", fontsize=13)
data = loadpkfile("data/trend_amplitude_section_model.bin")
for i in data.keys():
    locals()[i] = data[i]
secs = ["pn", "gf5", "ag4", "ea4", "bc5"]
lables = [
    " Kuroshio Current",
    "Gulf Stream",
    "Agulhas Current",
    "East Australian Current",
    "Brazil Current",
]
exps = [
    "CESM-iHESP",
    "CESM-TAMU",
    "HadGEM3-GC31-HH1",
    "sHadGEM3-GC31-HM",
    "sHadGEM3-GC31-MM",
    "sCMCC-CM2",
    "CNRM-CM6-1-HR",
    "sEC-Earth3P-HR",
]
colors = [
    "#e41a1c",
    "#377eb8",
    "#4daf4a",
    "#984ea3",
    "#ff7f00",
    "#ffff33",
    "#a65628",
    "#f781bf",
    "#999999",
]
colors1 = [
    "#e6194B",
    "#3cb44b",
    "#ffe119",
    "#4363d8",
    "#f58231",
    "#42d4f4",
    "#f032e6",
    "#dcbeff",
    "#9A6324",
    "#fffac8",
    "#800000",
    "#aaffc3",
    "#000075",
    "#a9a9a9",
    "#ffffff",
    "#000000",
]
ax = ax6
width = 0.1
x = np.arange(0, 10, 1.8)
emenall = []
estdall = []
for i in range(5):
    sec = secs[i]
    if i >= 2:
        tr = -treall[sec]
    else:
        tr = treall[sec]
    tr = tr * 10 * 100
    for j in range(8):
        bar = plt.bar(
            x[i] + width * j + 0.05,
            tr[j],
            width,
            color=colors1[j],
            hatch="///",
            # hatch_linewidth=2,
        )
    wmen = np.mean(tr)
    wstd = np.std(tr)

    wstd0 = bequ(tr)
    wstd = np.abs(wstd0[0] - wstd0[1]) / 2
    y = wmen
    y_err = wstd
    emenall.append(wmen)
    estdall.append(y_err)

    ax.errorbar(x[i] - 0.05, wmen, wstd, capsize=3, color="k", zorder=1)
    ax.scatter(x[i] - 0.05, wmen, color="k", zorder=2, s=20, marker="*")

ax.scatter(
    x[i] - 0.05, wmen, color="k", zorder=2, s=20, marker="*", label="offshore mean"
)
wmenall = []
wstdall = []
for i in range(5):
    sec = secs[i]
    if i >= 2:
        tr = -trwall[sec]
    else:
        tr = trwall[sec]
    tr = tr * 10 * 100
    for j in range(8):
        ax.bar(x[i] + width * j - 8 * 0.1 - 0.05, tr[j], width, color=colors1[j])

    wmen = np.mean(tr)
    wstd = np.std(tr)

    wstd0 = bequ(tr)
    wstd = np.abs(wstd0[0] - wstd0[1]) / 2
    y = wmen
    y_err = wstd

    wmenall.append(wmen)
    wstdall.append(y_err)

    ax.errorbar(x[i] - 0.05, wmen, wstd, capsize=3, color="k", zorder=1)
    ax.scatter(x[i] - 0.05, wmen, color="k", zorder=2, s=20)
ax.scatter(x[i] - 0.05, wmen, color="k", zorder=2, s=20, label="onshore mean")

for i in range(1):
    sec = secs[i]
    if i >= 2:
        tr = -trwall[sec]
    else:
        tr = trwall[sec]
    tr = tr * 10 * 100
    for j in range(8):
        ax.bar(
            x[i] + width * j - 8 * 0.1 - 0.05,
            tr[j],
            width,
            color=colors1[j],
            label=exps[j],
        )
ax.set_xticks(x[:5])
x1 = np.arange(-0.9, 9, 1.8)
print(x1)
for i in x1:
    i = i - 0.05
    plt.plot([i, i], [-5.5, 4], ls="--", color="black", lw=0.8)
plt.ylim([-5.5, 4])
plt.xlim([x1[0] - 0.05, x1[-1] - 0.05])

ax.set_xticklabels(lables, fontsize=12)
mpl.rcParams["hatch.linewidth"] = 0.3
ax.legend(ncol=3, fontsize=9)
ax.set_ylabel("$cm\ s^{-1}\ per\ decade$", fontsize=12)
ax.set_title("f", loc="left", fontweight="bold", fontsize=13)

plt.tight_layout(h_pad=1)

ax.set_position([0.067, 0.1, 0.868, 0.28])


plt.savefig("Figure2.pdf", bbox_inches="tight")





