#!/usr/bin/env python
# coding: utf-8



import struct
import warnings

import cartopy.crs as ccrs
import cartopy.feature as feature
import gsw
import matplotlib as mpl
import matplotlib.pylab as plt
import numpy as np
import scipy
import scipy.ndimage as si  # Another package for signal analysis
import scipy.signal as sg  # Package for signal analysis
import xarray as xr
from cartopy.mpl.ticker import LatitudeFormatter, LongitudeFormatter
from loaddata.loadbin import loadpkfile, savepkfile
from matplotlib import cm, colors
from scipy.io import loadmat
from scipy.ndimage import gaussian_filter

warnings.filterwarnings("ignore")
import matplotlib.ticker as mticker

formatter = mticker.ScalarFormatter(useOffset=False, useMathText=True)
formatter.set_powerlimits((-1, 2))





# broostrap code
def bequ(data):
    n_iterations = 2000
    sample_size = len(data)
    bootstrap_means = []
    for _ in range(n_iterations):
        bootstrap_sample = np.random.choice(data, size=sample_size, replace=True)
        bootstrap_mean = np.mean(bootstrap_sample)
        bootstrap_means.append(bootstrap_mean)
        confidence_interval = np.percentile(bootstrap_means, [2.5, 97.5])
    return confidence_interval





filename = "data/curl_his_rcp.mat"
data = loadmat(filename)
for i in data.keys():
    locals()[i] = data[i]

filename = "data/latlon.mat"
data = loadmat(filename)
for i in data.keys():
    locals()[i] = data[i]





def smooth2(a, nx, ny):
    from scipy import signal

    kernel = np.ones((nx, ny)) * 1 / (nx * ny)
    r = signal.convolve2d(a, kernel, mode="same")
    return r


def mygrid(xx, yy, data):
    points = data.ravel()
    xx, yy = xx.ravel(), yy.ravel()
    valid = ~np.isnan(points)
    points_valid = points[valid]
    xxv = xx[valid]
    yyv = yy[valid]

    interpolated = scipy.interpolate.griddata(
        np.stack([xxv, yyv]).T, points_valid, (xx, yy), method="nearest"
    )
    out = interpolated.reshape(data.shape)
    return out


curl_his_ensemble = mygrid(longi, lati, curl_his_ensemble)
curl_rcp_ensemble = mygrid(longi, lati, curl_rcp_ensemble)


dso = xr.Dataset(
    {
        "curl_his": (
            [
                "lon",
                "lat",
            ],
            curl_his_ensemble,
        ),
        "curl_rcp": (
            [
                "lon",
                "lat",
            ],
            curl_rcp_ensemble,
        ),
    },
    coords={
        "lon": (["lon"], longi[:, 0]),
        "lat": (["lat"], lati[0, :]),
    },
)
curl_his_ensemble = smooth2(curl_his_ensemble, 8, 8)
curl_rcp_ensemble = smooth2(curl_rcp_ensemble, 8, 8)




dso = xr.Dataset(
    {
        "curl_his": (
            [
                "lon",
                "lat",
            ],
            curl_his_ensemble,
        ),
        "curl_rcp": (
            [
                "lon",
                "lat",
            ],
            curl_rcp_ensemble,
        ),
    },
    coords={
        "lon": (["lon"], longi[:, 0]),
        "lat": (["lat"], lati[0, :]),
    },
)
lon1 = 120
lon2 = 260
lat1 = 0
lat2 = 45
lon = dso.lon
lat = dso.lat
crt = (lon >= lon1) & (lon <= lon2) & (lat >= lat1) & (lat <= lat2)
curlh = dso.curl_his.where(crt, drop=True)
curlr = dso.curl_rcp.where(crt, drop=True)




filename = "data/ts_profile.mat"
data = loadmat(filename)
for i in data.keys():
    locals()[i] = data[i]
pth = t_1950_ku_standard.copy()
ptr = t_2050_ku_standard.copy()
sh = s_1950_ku_standard.copy()
sr = s_2050_ku_standard.copy()
z = np.squeeze(np.float16(dep_standard.copy()))



cth = gsw.CT_from_pt(sh, pth)
ctr = gsw.CT_from_pt(sr, ptr)
p = np.squeeze(gsw.p_from_z(-z, lat=22.5))
x, y = cth.shape
n2h = np.zeros((x - 1, y))
n2r = np.zeros((x - 1, y))
n2rs = np.zeros((x - 1, y))
n2rt = np.zeros((x - 1, y))

for i in range(8):
    n2h[:, i], depthnh = gsw.Nsquared(sh[:, i], cth[:, i], p, )
    n2r[:, i], depthnr = gsw.Nsquared(sr[:, i], ctr[:, i], p, )
    n2rs[:, i], temp = gsw.Nsquared(sr[:, i], cth[:, i], p, )
    n2rt[:, i], temp = gsw.Nsquared(sh[:, i], ctr[:, i], p, )
colors1 = [
    "#e41a1c",
    "#377eb8",
    "#4daf4a",
    "#984ea3",
    "#ff7f00",
    "#ffff33",
    "#a65628",
    "#f781bf",
    "#999999",
]





dsp = xr.open_dataset("data/dcurl_pv.nc")





pv = dsp.pv.where(crt, drop=True)
temp = curlh.values
temp[np.isnan(pv)] = np.nan
curlh.values = temp
temp = curlr.values
temp[np.isnan(pv)] = np.nan
curlr.values = temp




pvo = pv.values
pvo[pvo > 0.05] = np.nan
pvo[~np.isnan(pvo)] = 0.1





fig = plt.figure(figsize=(7, 6.5))

myproj = ccrs.PlateCarree(central_longitude=(lon1 + lon2) / 2)
ax1 = plt.subplot2grid((3, 2), (0, 0), rowspan=1, colspan=2, projection=myproj)
im1 = curlh.T.plot.contourf(
    ax=ax1,
    transform=ccrs.PlateCarree(),
    levels=np.arange(-1.5e-7, 1.51e-7, 0.25e-7),
    extend="both",
    add_colorbar=0,
    # cmap=newcmp,
)


ax2 = plt.subplot2grid((3, 2), (1, 0), rowspan=1, colspan=2, projection=myproj)
im2 = (curlr - curlh).T.plot.contourf(
    ax=ax2,
    transform=ccrs.PlateCarree(),
    levels=np.arange(-1e-8, 1.01e-8, 0.2e-8),
    extend="both",
    add_colorbar=0,
)

nx, ny = pv.shape
lonp = pv.lon.values
latp = pv.lat.values
Lon, Lat = np.meshgrid(lonp, latp)
xx1 = 6
yy1 = 5
Lon, Lat = np.meshgrid(lonp[::xx1], latp[::yy1])
ax2.scatter(
    Lon.T.reshape(-1),
    Lat.T.reshape(-1),
    pvo[::xx1, ::yy1].reshape(-1),
    transform=ccrs.PlateCarree(),
    c="k",
    # s=20
)


cbar2 = fig.colorbar(im2, ax=ax2, shrink=0.9, pad=0.02, format=formatter)
cbar2.ax.get_yaxis().get_offset_text().set_position((7, 1))
cbar2.set_label("$\Delta$WSC($m\ s^{-2}$)")
cbar2.set_ticks(np.arange(-1.0e-8, 1.1e-8, 0.4e-8))

ax2.add_feature(feature.LAND, color="gray", zorder=2)
ax2.coastlines(color="k", zorder=2)

ax2.set_xticks(np.arange(120, 270, 30), crs=ccrs.PlateCarree())
ax2.set_yticks(np.arange(0, 45, 10), crs=ccrs.PlateCarree())
lon_formatter = LongitudeFormatter(zero_direction_label=False)
lat_formatter = LatitudeFormatter()
ax2.xaxis.set_major_formatter(lon_formatter)
ax2.yaxis.set_major_formatter(lat_formatter)
ax2.set_xlabel("")
ax2.set_ylabel("")
ax2.set_title("b", loc="right", fontweight="bold", fontsize=13)

cbar1 = fig.colorbar(im1, ax=ax1, shrink=0.9, pad=0.02, format=formatter)
cbar1.ax.get_yaxis().get_offset_text().set_position((7, 1))
cbar1.set_ticks(np.arange(-1.5e-7, 1.51e-7, 0.5e-7))
cbar1.set_label("WSC($m\ s^{-2}$)")

ax1.add_feature(feature.LAND, color="gray", zorder=2)
ax1.coastlines(color="k", zorder=2)

ax1.set_xticks(np.arange(120, 270, 30), crs=ccrs.PlateCarree())
ax1.set_yticks(np.arange(0, 45, 10), crs=ccrs.PlateCarree())
lon_formatter = LongitudeFormatter(zero_direction_label=False)
lat_formatter = LatitudeFormatter()
ax1.xaxis.set_major_formatter(lon_formatter)
ax1.yaxis.set_major_formatter(lat_formatter)
ax1.set_xlabel("")
ax1.set_ylabel("")
ax1.set_title("a", loc="right", fontweight="bold", fontsize=13)

plt.tight_layout()


ax = plt.subplot2grid((3, 30), (2, 1), rowspan=1, colspan=8)
pt = ptr - pth
tm = np.mean(pt, 1)

# ts = np.std(pt, 1)
# ts = bequ(pt)
ts = np.zeros((len(tm), 2))
for i in range(len(tm)):
    ts[i, 0], ts[i, 1] = bequ(pt[i, :])


ax.plot(tm, z, color=colors1[0])

ax.fill_betweenx(z, ts[:, 0], ts[:, 1], color=colors1[0], alpha=0.3)

# ax.fill_betweenx(z, tm - ts, tm + ts, color=colors1[0], alpha=0.3)
ax.set_ylim(2000, 0)
ax.set_xlim(-0.25, 1.4)
ax.set_xticks([0, 0.5, 1])
ax.axes.ticklabel_format(axis="y", style="sci", useMathText=True, scilimits=(-1, 1))
# ax.get_yaxis().get_offset_text().set_position((-0.2, 1))
ax.set_ylabel("Depth(m)")
ax.set_xlabel("$\Delta$T($^{\circ}$C)")
ax.set_title("c", loc="right", fontweight="bold", fontsize=13)

ax = plt.subplot2grid((3, 30), (2, 10), rowspan=1, colspan=8)

pt = sr - sh
tm = np.mean(pt, 1)
# ts = np.std(pt, 1)
# ts = bequ(pt)
ts = np.zeros((len(tm), 2))
for i in range(len(tm)):
    ts[i, 0], ts[i, 1] = bequ(pt[i, :])

ax.fill_betweenx(z, ts[:, 0], ts[:, 1], color=colors1[1], alpha=0.3)

ax.plot(tm, z, color=colors1[1])
# ax.fill_betweenx(z, tm - ts, tm + ts, color=colors1[1], alpha=0.3)
ax.set_ylim(2000, 0)
ax.set_yticklabels("")
ax.set_xlabel("$\Delta$S(g kg$^{-1}$)")
ax.set_title("d", loc="right", fontweight="bold", fontsize=13)


ax = plt.subplot2grid((3, 30), (2, 19), rowspan=1, colspan=8)

pt = n2r - n2h
tm = np.mean(pt, 1)
# ts = np.std(pt, 1)
# ts = bequ(pt)
ts = np.zeros((len(tm), 2))
for i in range(len(tm)):
    ts[i, 0], ts[i, 1] = bequ(pt[i, :])
ax.fill_betweenx(depthnh, ts[:, 0], ts[:, 1], color="k", alpha=0.3)

ax.plot(tm, depthnh, color="k", zorder=10, label="Total")


pt = n2rt - n2h
tm = np.mean(pt, 1)

ts = np.zeros((len(tm), 2))
for i in range(len(tm)):
    ts[i, 0], ts[i, 1] = bequ(pt[i, :])
ax.fill_betweenx(depthnh, ts[:, 0], ts[:, 1], color=colors1[0], alpha=0.3)

ax.plot(tm, depthnh, color=colors1[0], zorder=9, label="$\Delta$T")
ax.set_ylim(2000, 0)
ax.set_yticklabels("")

pt = n2rs - n2h
tm = np.mean(pt, 1)

ts = np.zeros((len(tm), 2))
for i in range(len(tm)):
    ts[i, 0], ts[i, 1] = bequ(pt[i, :])
ax.plot(tm, depthnh, color=colors1[1], zorder=8, label="$\Delta$S")
ax.fill_betweenx(depthnh, ts[:, 0], ts[:, 1], color=colors1[1], alpha=0.3)

ax.set_ylim(2000, 0)
ax.set_yticklabels("")
ax.axes.ticklabel_format(axis="x", style="sci", useMathText=True, scilimits=(-1, 1))
ax.set_xlabel("$\Delta$N$^{2}$(s$^{-2}$)")
ax.set_title("e", loc="right", fontweight="bold", fontsize=13)

plt.legend()
plt.savefig("Figure3.pdf", bbox_inches="tight")

