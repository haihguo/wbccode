#!/usr/bin/env python
# coding: utf-8

# In[16]:


import warnings

import cmaps
import matplotlib.pylab as plt
import numpy as np
import xarray as xr
from scipy.interpolate import interp1d

warnings.filterwarnings("ignore")
import struct

import matplotlib.colors as colorsx
import matplotlib.ticker as mticker

formatter = mticker.ScalarFormatter(useOffset=False, useMathText=True)
formatter.set_powerlimits((-1, 1))


# In[17]:


exp = ["ccase", "ht", "ltau", "htltau"]
titles = ["Central", "High Temp", "Low Wind", "Temp+Wind"]
filepath = "data/narrow/"
ii = 0
ds0 = xr.open_dataset(filepath + titles[ii] + ".nc")
ii = 1
dst = xr.open_dataset(filepath + titles[ii] + ".nc")
ii = 2
dsw = xr.open_dataset(filepath + titles[ii] + ".nc")
ii = 3
dsa = xr.open_dataset(filepath + titles[ii] + ".nc")
dsall = [ds0, dst, dsw, dsa]

y1 = 20
midy = 40
yy = np.arange(midy - y1, midy + y1)
Depth = xr.open_dataset(filepath + "modeldepth.nc").__xarray_dataarray_variable__


# In[18]:


titles = ["CTRL", "$\Delta\ N^2$ ", "$\Delta$ WIND", "WARMING"]



# In[19]:


filename = "data/colormap2.act"

DATA = []
with open(filename, "rb") as actFile:
    for _ in range(256):
        raw = actFile.read(3)
        color = struct.unpack("3B", raw)
        DATA.append(tuple([i / 255 for i in color]))
data1 = DATA[::16]  # []
color = (255, 255, 255)
xx = tuple([i / 255 for i in color])
data1[7] = xx
data1[8] = xx
newcmp = colorsx.LinearSegmentedColormap.from_list("chaos", data1[:])
newcmp


# In[20]:


fig = plt.figure(figsize=(12, 6))

xaxis = 358254.0

ds = dsall[0]

ax = plt.subplot2grid((10, 4), (0, 0), rowspan=5, colspan=1)
ax1 = ax
ii = 0
ds = dsall[ii]
data = (ds.VVEL[:, yy, :]).mean("YG")
im1 = data.plot.contourf(
    ax=ax,
    levels=np.arange(0, 1.21, 0.2),
    add_colorbar=0,
    extend="both",
    cmap=plt.cm.Reds,
)
depth = Depth[midy, :]
ax.plot(xaxis * np.ones(2), [-1000, 0], color="k", ls="--", lw=1, zorder=1)
ax.fill_between(depth.XC, -2000 * np.ones(len(depth)), -depth, color="gray", zorder=2)
ax.set_ylim(-1000, 0)
ax.set_xlim(0, 0.8e6)
ax.set_xlabel("")
ax.set_ylabel("Depth(m)")
ax.axes.ticklabel_format(style="sci", useMathText=True, scilimits=(-1, 1))
ax.set_title(titles[ii])
# ax.set_xticklabels([])
# ax.text(7.2e5, -100, "(a)")
ax.set_title("a", loc="right", fontweight="bold", fontsize=13)

ax.set_xlim(0, 0.8e6)
ax.set_xlabel("X(m)")
ax.axes.ticklabel_format(style="sci", useMathText=True, scilimits=(-1, 1))

ax = plt.subplot2grid((10, 4), (0, 2), rowspan=5, colspan=1)
ax3 = ax
ii = 1
ds = dsall[ii]
data = (ds.VVEL[:, yy, :]).mean("YG") - (ds0.VVEL[:, yy, :]).mean("YG")
im2 = data.plot.contourf(
    cmap=newcmp,
    ax=ax,
    levels=np.arange(-0.05, 0.051, 0.005),
    add_colorbar=0,
    extend="both",
)
ax.plot(xaxis * np.ones(2), [-1000, 0], color="k", ls="--", lw=1, zorder=1)
ax.fill_between(depth.XC, -2000 * np.ones(len(depth)), -depth, color="gray", zorder=2)
ax.set_ylim(-1000, 0)
ax.set_xlim(0, 0.8e6)
ax.set_xlabel("")
ax.set_ylabel("")
ax.set_title(titles[ii])
# ax.set_xticklabels([])
ax.set_yticklabels([])
# ax.text(7.2e5, -100, "(c)")
ax.set_title("c", loc="right", fontweight="bold", fontsize=13)

ax.set_xlim(0, 0.8e6)
ax.set_xlabel("X(m)")
ax.set_ylabel("")
ax.axes.ticklabel_format(axis="x", style="sci", useMathText=True, scilimits=(-1, 1))

ax = plt.subplot2grid((10, 4), (0, 3), rowspan=5, colspan=1)
ax4 = ax
ii = 2
ds = dsall[ii]
data = (ds.VVEL[:, yy, :]).mean("YG") - (ds0.VVEL[:, yy, :]).mean("YG")
im2 = data.plot.contourf(
    cmap=newcmp,
    ax=ax,
    levels=np.arange(-0.05, 0.051, 0.005),
    add_colorbar=0,
    extend="both",
)
ax.plot(xaxis * np.ones(2), [-1000, 0], color="k", ls="--", lw=1, zorder=1)
ax.fill_between(depth.XC, -2000 * np.ones(len(depth)), -depth, color="gray", zorder=2)
ax.set_ylim(-1000, 0)
ax.set_xlim(0, 0.8e6)
ax.set_xlabel("")
ax.set_ylabel("")
ax.set_title(titles[ii])
ax.set_yticklabels([])
# ax.text(7.2e5, -100, "(d)")
ax.set_title("d", loc="right", fontweight="bold", fontsize=13)

ax.set_xlim(0, 0.8e6)
ax.set_xlabel("X(m)")
ax.set_ylabel("")
ax.axes.ticklabel_format(axis="x", style="sci", useMathText=True, scilimits=(-1, 1))


ax = plt.subplot2grid((10, 4), (0, 1), rowspan=5, colspan=1)
ax2 = ax
ii = 3
ds = dsall[ii]
data = (ds.VVEL[:, yy, :]).mean("YG") - (ds0.VVEL[:, yy, :]).mean("YG")
im2 = data.plot.contourf(
    cmap=newcmp,
    ax=ax,
    levels=np.arange(-0.05, 0.051, 0.005),
    add_colorbar=0,
    extend="both",
)
ax.plot(xaxis * np.ones(2), [-1000, 0], color="k", ls="--", lw=1, zorder=1)
ax.fill_between(depth.XC, -2000 * np.ones(len(depth)), -depth, color="gray", zorder=2)
ax.set_ylim(-1000, 0)
ax.set_xlim(0, 0.8e6)
ax.set_ylabel("")
ax.set_title(titles[ii])
ax.set_yticklabels([])
# ax.text(7.2e5, -100, "(b)")
ax.set_title("b", loc="right", fontweight="bold", fontsize=13)

ax.set_xlim(0, 0.8e6)
ax.set_xlabel("X(m)")
ax.set_ylabel("")
ax.axes.ticklabel_format(axis="x", style="sci", useMathText=True, scilimits=(-1, 1))

cbar = plt.colorbar(
    im1,
    ax=[
        ax1,
    ],
    orientation="horizontal",
    pad=0.23,
    format=formatter,
)
cbar.set_label("$v(m\ s^{-1})$")

cbar = plt.colorbar(
    im2,
    ax=[ax2, ax3, ax4],
    orientation="horizontal",
    pad=0.23,
    format=formatter,
    aspect=70,
)
cbar.set_label("$\delta v(m\ s^{-1})$")


plt.savefig( "FigureE4.pdf", bbox_inches="tight")

