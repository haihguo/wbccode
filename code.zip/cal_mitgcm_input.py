#!/usr/bin/env python
# coding: utf-8




import numpy as np
import xarray as xr
import matplotlib.pylab as plt
from scipy.interpolate import interp1d
import cmaps 
import warnings
warnings.filterwarnings('ignore')
import matplotlib.ticker as mticker
formatter=mticker.ScalarFormatter(useOffset=False, useMathText=True)
formatter.set_powerlimits((-2, 4))

xx=(150*10+342*25)/100
xx 




layers = 20*[10]+6*[15]+4*[25]+4*[45]+4*[70]+5*[150]+2*[200]
print(len(layers))
n = len(layers)
dep = np.zeros(n)
dep[0] = layers[0]/2
for i in range(n-1):
    dep[i+1] = dep[i]+(layers[i]+layers[i+1])/2
print(dep)
print(np.sum(layers))



filenames = ['woa18_decav_t00_04.nc',]
colors = ['r','g','b']
filepath='data/'
lon1 = 130
lon2 = 240
lat1 = 15
lat2 = 30
dd = 100 #1000

trend = []
start = []
for i in range(1):
    filename=filepath+filenames[i]
    ds = xr.open_dataset(filename,decode_times=False)
    lon = ds.lon 
    lat = ds.lat
    crt = (lon>=lon1)&(lon<=lon2)&(lat>=lat1)&(lat<=lat2)
    t = ds.t_an.where(crt,drop=True)
    tm = t[0,:dd,:,:].mean('lon').mean('lat')
    # tm.plot(color=colors[i],y='depth')
# plt.ylim(2000,0)
T = np.interp(dep,ds.depth[:dd],tm)
plt.plot(dep,T)





nz = 45
nx = 342+150
ny = 156
sst = np.ones((ny,nx))*tm[0].values
windx = np.ones((ny,nx))
for i in range(ny):
    windx[i,:] = np.cos(i/ny*np.pi)*-0.056





topo = np.ones((ny, nx))*-2000
topo[:,:30] = -100
for i in range(70):
    topo[:,i+30] = np.interp(i,[-1,70],[-100,-2000])

topo[0, :] = 0
topo[-1, :] = 0
topo[:, 0] = 0
topo[:, -1] = 0
topo1 = topo.copy()
topo[topo == -2000] = np.nan




windx = np.ones((ny,nx))
for i in range(ny):
    windx[i,:] = np.cos(i/ny*np.pi)*-0.056*1.03

windx = np.ones((ny,nx))
for i in range(ny):
    windx[i,:] = np.cos(i/ny*np.pi)*-0.056*0.97




colors = ['#e41a1c','#377eb8','#4daf4a','#984ea3','#ff7f00','k',]
titles = ['CTRL','Warming']#,'Weak-wind','Warming & Weak-wind']

T = np.interp(dep,ds.depth[:dd],tm)
T0 = T.copy()

T = T0.copy()
ta = 1.6
Ta=ta*np.exp(-dep/200)
T = T+Ta
plt.plot(T,dep,color=colors[0],label=titles[1])

T = T0.copy()
plt.plot(T,dep,color=colors[2],label=titles[0])


plt.plot([0,27],[200,200],ls='--',lw=1,color='k')
plt.ylim(1000,0)
plt.xlabel('T($^{\circ}C$)')
plt.ylabel('Depth(m)')
plt.legend()





y = np.arange(0,156)*10e3
windx = np.ones((ny,nx))
for i in range(ny):
    windx[i,:] = np.cos(i/ny*np.pi)*-0.056
plt.plot(windx[:,0],y,label='CTRL',color=colors[2])
windx = np.ones((ny,nx))
for i in range(ny):
    windx[i,:] = np.cos(i/ny*np.pi)*-0.056*0.97

plt.plot(windx[:,0],y,label='Weak-wind',color=colors[1])

plt.legend()
plt.ticklabel_format(style='sci', useMathText=True, scilimits=(-3, 4))
plt.xlabel('Taux($N\ m^2$)')
plt.ylabel('Y(m)')



plt.subplots(1,3,figsize=(11,3))

plt.subplot(1,3,1)
x = np.arange(0,492*10e3,10e3)
y = np.arange(0,156*10e3,10e3)
X,Y = np.meshgrid(x,y)
im=plt.contourf(X,Y,-topo1,levels = np.arange(0,2001,200),cmap=plt.cm.GnBu)
cbar = plt.colorbar(im)
cbar.set_label('Depth(m)')

plt.plot([0,8e5],y[77]*np.ones(2),color='k',ls='-')
plt.plot(x[30]*np.ones(2),[y[0],y[-1]],color='k',ls='--')

plt.xlim(0,2e6)
plt.xlabel('X(m)')
plt.ylabel('Y(m)')
plt.ylim(0,1.5e6)
plt.ticklabel_format(style='sci', useMathText=True, scilimits=(-3, 4))
plt.title('a',loc='right', fontweight="bold",fontsize=13)

plt.subplot(1,3,2)
colors = ['#e41a1c','#377eb8','#4daf4a','#984ea3','#ff7f00','k',]
titles = ['Control','Warming']#,'Weak-wind','Warming & Weak-wind']

titles1 = ['CTRL','$\Delta\ N^2$ ','$\Delta$ WIND','WARMING']

T = np.interp(dep,ds.depth[:dd],tm)
T0 = T.copy()
T = T0.copy()
ta = 1.6
Ta=ta*np.exp(-dep/200)
T = T+Ta
plt.plot(T,dep,color=colors[0],label=titles1[1])
T = T0.copy()
plt.plot(T,dep,color=colors[2],label=titles1[0])
# plt.plot([0,27],[200,200],ls='--',lw=1,color='k')
plt.xlim([3,30])
plt.ylim(1000,0)
plt.xlabel('T($^{\circ}C$)')
plt.ylabel('Depth(m)')
plt.legend()
plt.title('b',loc='right', fontweight="bold",fontsize=13)

plt.subplot(1,3,3)
y = np.arange(0,156)*10e3
windx = np.ones((ny,nx))
for i in range(ny):
    windx[i,:] = np.cos(i/ny*np.pi)*-0.056
plt.plot(windx[:,0],y,label=titles1[0],color=colors[2])
windx = np.ones((ny,nx))
for i in range(ny):
    windx[i,:] = np.cos(i/ny*np.pi)*-0.056*0.97

plt.plot(windx[:,0],y,label=titles1[2],color=colors[1])
plt.legend()
plt.ticklabel_format(style='sci', useMathText=True, scilimits=(-3, 4))
plt.xlabel(chr(964)+u'$_x$($N\ m^{-2}$)')
plt.ylabel('Y(m)')
plt.title('c',loc='right', fontweight="bold",fontsize=13)
plt.tight_layout()
plt.savefig('FigureE2.pdf',bbox_inches='tight')






