#!/usr/bin/env python
# coding: utf-8



import warnings

import cmaps
import matplotlib.pylab as plt
import numpy as np
import xarray as xr
from scipy.interpolate import interp1d

warnings.filterwarnings("ignore")
import matplotlib.ticker as mticker
import struct

import matplotlib.colors as colorsx
formatter = mticker.ScalarFormatter(useOffset=False, useMathText=True)
formatter.set_powerlimits((-1, 1))





exp = ["ccase", "ht", "ltau", "htltau"]
titles = ["CTRL", "Warming", "Weak-wind", "Warming + Weak-wind"]
filepath = "data/"
ii = 0
ds0 = xr.open_dataset(filepath + titles[ii] + ".nc")
ii = 1
dst = xr.open_dataset(filepath + titles[ii] + ".nc")
ii = 2
dsw = xr.open_dataset(filepath + titles[ii] + ".nc")
ii = 3
dsa = xr.open_dataset(filepath + titles[ii] + ".nc")
dsall = [ds0, dst, dsw, dsa]

y1 = 20
midy = 40
yy = np.arange(midy - y1, midy + y1)
Depth = xr.open_dataset(filepath + "modeldepth.nc").__xarray_dataarray_variable__
colors = [
    "#e6194B",
    "#3cb44b",
    "#ffe119",
    "#4363d8",
    "#f58231",
    "#42d4f4",
    "#f032e6",
    "#fabed4",
    "#469990",
    "#dcbeff",
    "#9A6324",
    "#fffac8",
    "#800000",
    "#aaffc3",
    "#000075",
    "#a9a9a9",
    "#ffffff",
    "#000000",
]





titles = [
    "Control",
    "Enhanced Stratification",
    "Weakened Wind",
    "Enhanced Stratification &\n Weakened Wind",
]
titles = ["Control", "$\Delta$ Temp.", "$\Delta$ Wind", "Warming"]
titles = ["CTRL", "$\Delta\ N^2$ ", "$\Delta$ Wind", "Warming"]
titles = ["CTRL", "$\Delta\ N^2$ ", "$\Delta$ WIND", "WARMING"]






filename = "data/colormap2.act"

DATA = []
with open(filename, "rb") as actFile:
    for _ in range(256):
        raw = actFile.read(3)
        color = struct.unpack("3B", raw)
        DATA.append(tuple([i / 255 for i in color]))
data1 = DATA[::16]#[]
color = (255, 255, 255)
xx = tuple([i / 255 for i in color])
data1[7] = xx
data1[8] = xx
newcmp = colorsx.LinearSegmentedColormap.from_list("chaos", data1[:])
newcmp




# from extended data table
n0 = np.array([2.06, 2.35, 2.20, 2.30, 2.11])
nd = np.array([0.15, 0.16, 0.14, 0.11, 0.13])

w0 = np.array([-6.4, -7.3, 7.2, 5.1, 5.8])
wd = np.array([0.19, 0.23, -0.46, -0.07, -0.24])

nb = np.cbrt(nd / n0)
wb = np.cbrt(wd / w0)
dd = np.abs(nb / wb)

dn = np.array([69, 71, 49, 78, 59])
an = np.array([69, 72, 51, 73, 58])

dw = np.array([32, 30, 52, 22, 42])
aw = np.array([35, 25, 52, 15, 39])


nm = (dn + an) / 2
wm = (dw + aw) / 2








fig = plt.figure(figsize=(12, 6))


ds = dsall[0]

ax = plt.subplot2grid((10, 4), (0, 0), rowspan=5, colspan=1)
ax1 = ax
ii = 0
ds = dsall[ii]
data = (ds.VVEL[:, yy, :]).mean("YG")
im1 = data.plot.contourf(
    ax=ax,
    levels=np.arange(0, 1.21, 0.2),
    add_colorbar=0,
    extend="both",
    cmap=plt.cm.Reds,
)
depth = Depth[midy, :]
ax.plot(ds.XC[40].values * np.ones(2), [-1000, 0], color="k", ls="--", lw=1, zorder=1)
ax.fill_between(depth.XC, -2000 * np.ones(len(depth)), -depth, color="gray", zorder=2)
ax.set_ylim(-1000, 0)
ax.set_xlim(0, 0.8e6)
ax.set_xlabel("")
ax.set_ylabel("Depth(m)")
ax.axes.ticklabel_format(style="sci", useMathText=True, scilimits=(-1, 1))
ax.set_title(titles[ii])
# ax.set_xticklabels([])
# ax.text(7.2e5, -100, "(a)")
ax.set_title("a", loc="right", fontweight="bold", fontsize=13)

ax.set_xlim(0, 0.8e6)
ax.set_xlabel("X(m)")
ax.axes.ticklabel_format(style="sci", useMathText=True, scilimits=(-1, 1))

ax = plt.subplot2grid((10, 4), (0, 2), rowspan=5, colspan=1)
ax3 = ax
ii = 1
ds = dsall[ii]
data = (ds.VVEL[:, yy, :]).mean("YG") - (ds0.VVEL[:, yy, :]).mean("YG")
im2 = data.plot.contourf(
    cmap=newcmp,
    ax=ax,
    levels=np.arange(-0.05, 0.051, 0.005),
    add_colorbar=0,
    extend="both",
)
ax.plot(ds.XC[40].values * np.ones(2), [-1000, 0], color="k", ls="--", lw=1, zorder=1)
ax.fill_between(depth.XC, -2000 * np.ones(len(depth)), -depth, color="gray", zorder=2)
ax.set_ylim(-1000, 0)
ax.set_xlim(0, 0.8e6)
ax.set_xlabel("")
ax.set_ylabel("")
ax.set_title(titles[ii])
# ax.set_xticklabels([])
ax.set_yticklabels([])
# ax.text(7.2e5, -100, "(c)")
ax.set_title("c", loc="right", fontweight="bold", fontsize=13)

ax.set_xlim(0, 0.8e6)
ax.set_xlabel("X(m)")
ax.set_ylabel("")
ax.axes.ticklabel_format(axis="x", style="sci", useMathText=True, scilimits=(-1, 1))

ax = plt.subplot2grid((10, 4), (0, 3), rowspan=5, colspan=1)
ax4 = ax
ii = 2
ds = dsall[ii]
data = (ds.VVEL[:, yy, :]).mean("YG") - (ds0.VVEL[:, yy, :]).mean("YG")
im2 = data.plot.contourf(
    cmap=newcmp,
    ax=ax,
    levels=np.arange(-0.05, 0.051, 0.005),
    add_colorbar=0,
    extend="both",
)
ax.plot(ds.XC[40].values * np.ones(2), [-1000, 0], color="k", ls="--", lw=1, zorder=1)
ax.fill_between(depth.XC, -2000 * np.ones(len(depth)), -depth, color="gray", zorder=2)
ax.set_ylim(-1000, 0)
ax.set_xlim(0, 0.8e6)
ax.set_xlabel("")
ax.set_ylabel("")
ax.set_title(titles[ii])
ax.set_yticklabels([])
# ax.text(7.2e5, -100, "(d)")
ax.set_title("d", loc="right", fontweight="bold", fontsize=13)

ax.set_xlim(0, 0.8e6)
ax.set_xlabel("X(m)")
ax.set_ylabel("")
ax.axes.ticklabel_format(axis="x", style="sci", useMathText=True, scilimits=(-1, 1))


ax = plt.subplot2grid((10, 4), (0, 1), rowspan=5, colspan=1)
ax2 = ax
ii = 3
ds = dsall[ii]
data = (ds.VVEL[:, yy, :]).mean("YG") - (ds0.VVEL[:, yy, :]).mean("YG")
im2 = data.plot.contourf(
    cmap=newcmp,
    ax=ax,
    levels=np.arange(-0.05, 0.051, 0.005),
    add_colorbar=0,
    extend="both",
)
ax.plot(ds.XC[40].values * np.ones(2), [-1000, 0], color="k", ls="--", lw=1, zorder=1)
ax.fill_between(depth.XC, -2000 * np.ones(len(depth)), -depth, color="gray", zorder=2)
ax.set_ylim(-1000, 0)
ax.set_xlim(0, 0.8e6)
ax.set_ylabel("")
ax.set_title(titles[ii])
ax.set_yticklabels([])
# ax.text(7.2e5, -100, "(b)")
ax.set_title("b", loc="right", fontweight="bold", fontsize=13)

ax.set_xlim(0, 0.8e6)
ax.set_xlabel("X(m)")
ax.set_ylabel("")
ax.axes.ticklabel_format(axis="x", style="sci", useMathText=True, scilimits=(-1, 1))

cbar = plt.colorbar(
    im1,
    ax=[
        ax1,
    ],
    orientation="horizontal",
    pad=0.23,
    format=formatter,
)
cbar.set_label("$v(m\ s^{-1})$")

cbar = plt.colorbar(
    im2,
    ax=[ax2, ax3, ax4],
    orientation="horizontal",
    pad=0.23,
    format=formatter,
    aspect=70,
)
cbar.set_label("$\delta v(m\ s^{-1})$")


ax = plt.subplot2grid((10, 4), (6, 0), rowspan=4, colspan=1)
lables = []
labelsall = {
    "kc": "KC",
    "gs": "GS",
    "ac": "AC",
    "ea": "EAC",
    "bc": "BC",
}
wbcs = ["kc", "gs", "ac", "ea", "bc"]
width = 0.3
xx = np.arange(0, 5)
for i in range(5):
    ax.bar(xx[i], nm[i], width, color=colors[i], edgecolor="k")
    ax.bar(xx[i] + 0.3, wm[i], width, color=colors[i], hatch="//", edgecolor="k")

i = 4
ax.bar(xx[i], 0, width, color="w", edgecolor="k", facecolor="w", label="$\Delta\ N^2$ ")
ax.bar(
    xx[i] + 0.3,
    0,
    width,
    color="w",
    hatch="///",
    edgecolor="k",
    facecolor="w",
    label="$\Delta$ Wind",
)

xticks = xx + 0.15
ax.set_xticks(xticks)
ax.set_xticklabels([labelsall[i] for i in labelsall.keys()])
ax.set_ylabel("Contribution(%)")
plt.legend(loc=(1.01, 0.4))
ax.set_title("e", loc="right", fontweight="bold", fontsize=13)


plt.savefig( "Figure4.pdf", bbox_inches="tight")

