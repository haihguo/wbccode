#!/usr/bin/env python
# coding: utf-8


import numpy as np
import xarray as xr
import matplotlib.pylab as plt
from loadbin import loadpkfile,savepkfile




data = loadpkfile('data/mitgcm_v_integrate.bin')
for i in data.keys():
    locals()[i] = data[i]


# In[18]:


ii = [0,1,2,3]
colors = ['k','#e41a1c','#377eb8','#4daf4a','#984ea3','#ff7f00','k',]
trw = []
tre = []
axis = []
plt.figure(figsize=(7,7))
xxl = np.arange(20,60,1)
plt.subplot(2,1,1)
for i in range(4):
    vv = vvall[i]
    plt.plot(xx,vv,label=titles1[i],color=colors[i],zorder=10)
    x1 = np.where(vv==np.max(vv))[0][0]
    trw.append(np.sum(vv[:x1])/np.sum(vv))
    tre.append(np.sum(vv[x1:])/np.sum(vv))
    axis.append(xx[x1])
plt.title('a',loc='left', fontweight="bold",fontsize=13)
plt.xlabel('X(m)')
plt.ticklabel_format(style='sci', useMathText=True, scilimits=(-2, 4))
plt.ylabel('UH')
plt.legend()

trw = trw-trw[0]
tre = tre-tre[0]
trw0 = trw.copy()
tre0 = tre.copy()

plt.subplot(2,1,2)
plt.scatter(titles1,tre,label='offshore',color=colors[2])
for i in range(4):
    plt.errorbar(titles1[i],tre[i],np.std(treall[:,i]),capsize=4,color=colors[2])

plt.scatter(titles1,trw,label='onshore',color=colors[1])
for i in range(4):
    plt.errorbar(titles1[i],trw[i],np.std(trwall[:,i]),capsize=4,color=colors[1],zorder=10)

plt.title('b',loc='left', fontweight="bold",fontsize=13)
plt.legend()
plt.xlabel('Run')
plt.ylabel('Transport anomaly')
plt.savefig('FigureE3.pdf',bbox_inches='tight')






