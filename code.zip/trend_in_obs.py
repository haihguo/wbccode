#!/usr/bin/env python
# coding: utf-8




import struct
import warnings

import cartopy.crs as ccrs
import cartopy.feature as feature
import cmaps
import matplotlib.pylab as plt
import matplotlib.ticker as mticker
import numpy as np
import xarray as xr
from cartopy.mpl.gridliner import LATITUDE_FORMATTER, LONGITUDE_FORMATTER
from cartopy.mpl.ticker import LatitudeFormatter, LongitudeFormatter
from cartopy.util import add_cyclic_point
from loadbin import loadpkfile, savepkfile
from matplotlib import cm, colors
from mpl_toolkits.axes_grid1 import make_axes_locatable

warnings.filterwarnings("ignore")

formatter = mticker.ScalarFormatter(useOffset=False, useMathText=True)
formatter.set_powerlimits((-3, 4))




dsm = xr.open_dataset("data/mean_aviso.nc")
dsu = xr.open_dataset("data/obs_u_trend.nc")
dsu1 = xr.open_dataset("data/mean_ke.nc")




filename = "data/colormap1.act"
DATA = []
with open(filename, "rb") as actFile:
    for _ in range(256):
        raw = actFile.read(3)
        color = struct.unpack("3B", raw)
        DATA.append(tuple([i / 255 for i in color]))
data1 = DATA[::16]
color = (249, 246, 238)
color = (255, 255, 255)
xx = tuple([i / 255 for i in color])
data1[7] = xx
data1[8] = xx
newcmp = colors.LinearSegmentedColormap.from_list("chaos", data1[:])
newcmp

newcmp1 = colors.LinearSegmentedColormap.from_list(
    "chaos1",
    (
        [
            "#F9F6EE",
            "#F9F6EE",
            "#ffae8b",
            "#ff9274",
            "#ff765d",
            "#ff5847",
            "#ff3632",
            "#ff001d",
            "#e90007",
            "#cb0000",
            "#af0000",
            "#930000",
        ]
    ),
)




lon1all = {
    "kc": 125.5,
    "gs": -80 + 360,
    "ac": 31,
    "ea": 150,
    "bc": -45 + 360,
}
lon2all = {
    "kc": 131,
    "gs": -74 + 360,
    "ac": 38,
    "ea": 156,
    "bc": -39 + 360,
}
lat1all = {"kc": 27, "gs": 31.25, "ac": -30, "ea": -35, "bc": -26}
lat2all = {
    "kc": 30.5,
    "gs": 35,
    "ac": -25.5,
    "ea": -31,
    "bc": -22,
}
levelsall = {
    "kc": np.arange(-3e-2, 3.01e-2, 0.5e-2) * 100,
    "gs": np.arange(-5e-2, 5.01e-2, 1e-2) * 100,
    "ac": np.arange(-3e-2, 3.01e-2, 0.5e-2) * 100,
    "ea": np.arange(-6e-2, 6.01e-2, 1e-2) * 100,
    "bc": np.arange(-3e-2, 3.01e-2, 0.5e-2) * 100,
}
adtalls = {
    "kc": 1.1,
    "gs": 0.4,
    "ac": 0.9,
    "ea": 0.9,
    "bc": 0.6,
}
bars = {
    "kc": np.arange(-3e-2, 3.01e-2, 1e-2) * 100,
    "gs": np.arange(-4e-2, 5.01e-2, 2e-2) * 100,
    "ac": np.arange(-3e-2, 3.01e-2, 1e-2) * 100,
    "ea": np.arange(-6e-2, 6.01e-2, 2e-2) * 100,
    "bc": np.arange(-3e-2, 3.01e-2, 1e-2) * 100,
}

titles = {
    "kc": "b",
    "gs": "c",
    "ac": "d",
    "ea": "e",
    "bc": "f",
}


lonpall = {}
latpall = {}

wbc = "kc"
lat1 = 27.5
lon1 = 128.25
lat2 = 30.5
lon2 = 124.5
cor = np.polyfit([lon1, lon2], [lat1, lat2], deg=1)
lonp = np.arange(126, 130.01, 0.1)
latp = lonp * cor[0] + cor[1]
lonpall.update({wbc: lonp})
latpall.update({wbc: latp})


wbc = "gs"
lat1 = 30
lat2 = 34
lon1 = -75
lon2 = -79.5
cor = np.polyfit([lon1, lon2], [lat1, lat2], deg=1)
lonp = np.arange(lon2 + 1, -76, 0.1)
latp = lonp * cor[0] + cor[1]
lonpall.update({wbc: lonp})
latpall.update({wbc: latp})

wbc = "ac"
lat1 = -29.5
lon1 = 36.5
lat2 = -26
lon2 = 32
cor = np.polyfit([lon1, lon2], [lat1, lat2], deg=1)
lonp = np.arange(lon2, lon1 + 0.01, 0.1)
latp = lonp * cor[0] + cor[1]
lonpall.update({wbc: lonp})
latpall.update({wbc: latp})

wbc = "ea"

lat0 = -33  # ea4
lon1 = 151
lon2 = 157
lon = np.arange(lon1, lon2 - 2 + 0.01, 0.1)
lonp = lon[:]
latp = np.ones(len(lon)) * lat0

lonpall.update({wbc: lonp})
latpall.update({wbc: latp})

wbc = "bc"
lon1 = -42.5
lon2 = -41

lat1 = -23
lat2 = -26
cor = np.polyfit([lon1, lon2], [lat1, lat2], deg=1)
lonp = np.arange(lon1, lon2 + 0.01, 0.1)
latp = lonp * cor[0] + cor[1]

lonpall.update({wbc: lonp})
latpall.update({wbc: latp})

xticksall = {
    "kc": np.arange(126, lon2all["kc"] + 1, 2),
    "gs": np.arange(-78, lon2all["gs"] + 1, 2),
    "ac": np.arange(32, lon2all["ac"] + 1, 2),
    "ea": np.arange(151, lon2all["ea"] + 1, 2),
    "bc": np.arange(316 - 360, lon2all["bc"] + 1, 2),
}

yticksall = {
    "kc": np.arange(26, lat2all["kc"] + 1, 1),
    "gs": np.arange(32, lat2all["gs"] + 1, 1),
    "ac": np.arange(-29, lat2all["ac"] + 1, 1),
    "ea": np.arange(-34, lat2all["ea"] + 1, 1),
    "bc": np.arange(-25, lat2all["bc"] + 1, 1),
}

labelsall = {
    "kc": "Kuroshio Current",
    "gs": "Gulf Stream",
    "ac": "Agulhas Current",
    "ea": "   East Australian Current",
    "bc": "Brazil Current",
}



lon1 = -180
lon2 = 180
lat1 = -90
lat2 = 90
ds = dsu1
lon = ds.longitude
lat = ds.latitude
crt = (lon >= lon1) & (lon <= lon2) & (lat >= lat1) & (lat <= lat2)

data = ds.eke[0, :, :].where(crt, drop=True)
temp = data.values
temp[339:381, :] = np.nan
data.values = temp
fig = plt.figure(figsize=(11, 7.5))

myproj = ccrs.LambertCylindrical(central_longitude=180)

ax = plt.subplot2grid((11, 10), (0, 0), colspan=10, rowspan=5, projection=myproj)

pre_reg_cyc, lon_cyc = add_cyclic_point(data, coord=data.longitude)
Lon, Lat = np.meshgrid(lon_cyc, data.latitude)
Lon, Lat = np.meshgrid(lon_cyc, data.latitude)

im = ax.contourf(
    Lon,
    Lat,
    pre_reg_cyc,
    transform=ccrs.PlateCarree(),
    add_colorbar=0,
    cmap=newcmp1,
    levels=np.arange(0, 0.301, 0.025),
    extend="max",
)

ax.add_feature(feature.LAND, color="gray", zorder=2)
ax.coastlines(color="k", zorder=2, linewidth=0.5)
gl = ax.gridlines(
    xlocs=[-120, -60, 60, 120, -180],
    ylocs=[-60, -30, 0, 30, 60],
    draw_labels=True,
    x_inline=False,
    y_inline=False,
    linewidth=0.6,
    color="gray",
    alpha=0.5,
    linestyle="--",
    dms=True,
)
gl.xlabels_top = False
gl.xlabels_bottom = True

lon_formatter = LongitudeFormatter(zero_direction_label=False)
lat_formatter = LatitudeFormatter()
gl.xformatter = lon_formatter
gl.yformatter = lat_formatter

ax.text(130, 20, "KC", transform=ccrs.PlateCarree(), ha="center", va="center")
ax.text(-70, 25, "GS", transform=ccrs.PlateCarree(), ha="center", va="center")
ax.text(40, -35, "AC", transform=ccrs.PlateCarree(), ha="center", va="center")
ax.text(165, -33, "EAC", transform=ccrs.PlateCarree(), ha="center", va="center")
ax.text(-30, -25, "BC", transform=ccrs.PlateCarree(), ha="center", va="center")


cbar = plt.colorbar(im, shrink=0.8, pad=0.005, aspect=35)
cbar.set_ticks(np.arange(0, 0.301, 0.05))
cbar.set_label("Kinetic energy($m^2\ s^{-2}$)", fontsize=9)
ax.set_title("a", loc="left", fontweight="bold", fontsize=13)


wbc = "kc"
lon1 = lon1all[wbc]
lon2 = lon2all[wbc]
myproj = ccrs.PlateCarree(central_longitude=(lon1 + lon2) / 2)
ax1 = plt.subplot2grid((11, 10), (5, 0), colspan=3, rowspan=3, projection=myproj)
wbc = "gs"
lon1 = lon1all[wbc]
lon2 = lon2all[wbc]
myproj = ccrs.PlateCarree(central_longitude=(lon1 + lon2) / 2)
ax2 = plt.subplot2grid((11, 10), (5, 3), colspan=3, rowspan=3, projection=myproj)
wbc = "ac"
lon1 = lon1all[wbc]
lon2 = lon2all[wbc]
myproj = ccrs.PlateCarree(central_longitude=(lon1 + lon2) / 2)
ax3 = plt.subplot2grid((11, 10), (5, 6), colspan=3, rowspan=3, projection=myproj)
wbc = "ea"
lon1 = lon1all[wbc]
lon2 = lon2all[wbc]
myproj = ccrs.PlateCarree(central_longitude=(lon1 + lon2) / 2)
ax4 = plt.subplot2grid((11, 10), (8, 0), colspan=3, rowspan=3, projection=myproj)
wbc = "bc"
lon1 = lon1all[wbc]
lon2 = lon2all[wbc]
myproj = ccrs.PlateCarree(central_longitude=(lon1 + lon2) / 2)
ax5 = plt.subplot2grid((11, 10), (8, 3), colspan=3, rowspan=3, projection=myproj)


axall = {
    "kc": ax1,
    "gs": ax2,
    "ac": ax3,
    "ea": ax4,
    "bc": ax5,
}
wbcs = ["ac", "bc", "ea", "gs", "kc"]
secs = ["ag4", "bc5", "ea4", "gf5", "pn"]
time = np.arange(0, 101, 1)
nw = len(wbcs)
for iw in range(nw):
    sec = secs[iw]
    wbc = wbcs[iw]
    ax = axall[wbc]
    lon1 = lon1all[wbc]
    lon2 = lon2all[wbc]
    lat1 = lat1all[wbc]
    lat2 = lat2all[wbc]
    if lon2 >= 180:
        lon2 = lon2 - 360
        lon1 = lon1 - 360
    crt = (lon >= lon1) & (lon <= lon2) & (lat >= lat1) & (lat <= lat2)
    data = dsu.t1.where(crt, drop=True) * 120 * 100
    adt = dsm.adt.where(crt, drop=True)
    data2 = dsu.p1.where(crt, drop=True)

    im = data.plot.contourf(
        ax=ax,
        transform=ccrs.PlateCarree(),
        add_colorbar=0,
        cmap=newcmp,
        extend="both",
        levels=levelsall[wbc],
    )
    cbar = plt.colorbar(im, shrink=0.8, pad=0.03, format=formatter)
    cbar.ax.get_yaxis().get_offset_text().set_position((7, 1))
    cbar.set_ticks(bars[wbc])
    cbar.ax.tick_params(axis="y", labelsize=9)
    adt[0, 0, :, :].plot.contour(
        ax=ax,
        transform=ccrs.PlateCarree(),
        levels=[
            adtalls[wbc],
        ],
        colors="k",
        linewidths=2,
    )

    lon0 = data2.longitude.values
    lat0 = data2.latitude.values
    ny, nx = data2.shape
    data2va = data2.values
    data2va[data2va > 0.05] = np.nan
    data2va[~np.isnan(data2va)] = 0.3
    Lon0, Lat0 = np.meshgrid(lon0, lat0)
    ax.scatter(Lon0, Lat0, data2va, transform=ccrs.PlateCarree(), color="k")

    ax.add_feature(feature.LAND, color="gray", zorder=5)
    ax.coastlines(color="k", zorder=6)
    lonp = lonpall[wbc]
    latp = latpall[wbc]
    ax.plot(lonp, latp, transform=ccrs.PlateCarree(), ls="--", color="k")
    ax.set_xticks(xticksall[wbc], crs=ccrs.PlateCarree())
    ax.set_yticks(yticksall[wbc], crs=ccrs.PlateCarree())
    lon_formatter = LongitudeFormatter(zero_direction_label=False)
    lat_formatter = LatitudeFormatter()
    ax.xaxis.set_major_formatter(lon_formatter)
    ax.yaxis.set_major_formatter(lat_formatter)
    ax.tick_params(axis="y", labelsize=9)
    ax.tick_params(axis="y", labelsize=9)

    ax.set_xlabel("")
    ax.set_ylabel("")

    ax.set_title(labelsall[wbc])
    ax.set_extent([lon1 + 0.125, lon2 - 0.125, lat1 + 0.125, lat2 - 0.125])
    print(lon1)
    ax.text(
        lon1 - 0.25,
        lat2 + 0.125,
        titles[wbc],
        transform=ccrs.PlateCarree(),
        fontweight="bold",
        fontsize=13,
    )

ax = plt.subplot2grid((11, 10), (8, 6), colspan=3, rowspan=3)
secs = ["kc", "gf", "ag", "ea", "bc"]
name = ["KC", "GS", "AC", "EAC", "BC"]
aa = 1.5
xticks = np.arange(0, 5)
colors = [
    "#e6194B",
    "#377eb8",
    "#3cb44b",
    "#984ea3",
    "#ff7f00",
    "k",
]
lin = loadpkfile("data/trend_amplitude_section.bin")
for i in lin.keys():
    locals()[i] = lin[i]

for ii, sec in enumerate(secs):
    ax.scatter(xticks[ii], lin[sec]["pw"] * 100, color=colors[0], zorder=2, s=20)
    ax.scatter(
        xticks[ii], lin[sec]["pe"] * 100, marker="*", color=colors[2], zorder=2, s=30
    )
    data = (lin[sec]["cw"][1] - lin[sec]["cw"][0]) / 2 * 100
    ax.errorbar(xticks[ii], lin[sec]["pw"] * 100, data, capsize=4, color=colors[0])

    data = (lin[sec]["ce"][1] - lin[sec]["ce"][0]) / 2 * 100
    ax.errorbar(xticks[ii], lin[sec]["pe"] * 100, data, capsize=4, color=colors[2])

ax.scatter(
    xticks[ii], lin[sec]["pw"] * 100, color=colors[0], zorder=2, s=20, label="onshore"
)
ax.scatter(
    xticks[ii],
    lin[sec]["pe"] * 100,
    marker="*",
    color=colors[2],
    zorder=2,
    s=30,
    label="offshore",
)
legend = ax.legend(loc=(0.07, 1.01), ncol=2, handlelength=1, handletextpad=0)


ax.set_xlim(-0.5, 4.5)

ax.plot([-0.5, 4.5], [0, 0], ls="--", lw=1, color="k")
ax.set_xticks(xticks)
ax.set_xticklabels(name)
ax.set_ylabel("$cm\ s^{-1}\ per\ decade$", fontweight="bold", fontsize=13)
ax.yaxis.tick_right()
ax.yaxis.set_label_position("right")


ax.text(-0.8, 7, "g", fontweight="bold", fontsize=13)

ax.tick_params(width=aa)

ax.plot([-0.5, 4.5], [0, 0], ls="--", lw=1, color="k")

ax.set_yticks(np.arange(-4, 5.1, 2))

plt.tight_layout(pad=0.4, w_pad=0.3, h_pad=0.5)

ax.set_position([0.648, 0.05, 0.203, 0.193])

plt.savefig("Figure1.pdf", bbox_inches="tight")





