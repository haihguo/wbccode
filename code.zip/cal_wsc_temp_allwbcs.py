#!/usr/bin/env python
# coding: utf-8



import struct
import warnings

import cartopy.crs as ccrs
import cartopy.feature as feature
import gsw
import matplotlib as mpl
import matplotlib.pylab as plt
import numpy as np
import scipy
import scipy.ndimage as si  # Another package for signal analysis
import scipy.signal as sg  # Package for signal analysis
import xarray as xr
from cartopy.mpl.ticker import LatitudeFormatter, LongitudeFormatter
from matplotlib import cm, colors
from scipy.io import loadmat
from scipy.ndimage import gaussian_filter

warnings.filterwarnings("ignore")
import matplotlib.ticker as mticker

formatter = mticker.ScalarFormatter(useOffset=False, useMathText=True)
formatter.set_powerlimits((-1, 2))








# In[6]:


# broostrap code
def bequ(data):
    n_iterations = 2000
    sample_size = len(data)
    bootstrap_means = []
    for _ in range(n_iterations):
        bootstrap_sample = np.random.choice(data, size=sample_size, replace=True)
        bootstrap_mean = np.mean(bootstrap_sample)
        bootstrap_means.append(bootstrap_mean)
        confidence_interval = np.percentile(bootstrap_means, [2.5, 97.5])
    return confidence_interval





filename =  "data/curl_his_rcp.mat"
data = loadmat(filename)
for i in data.keys():
    locals()[i] = data[i]

filename = "data/latlon.mat"
data = loadmat(filename)
for i in data.keys():
    locals()[i] = data[i]




def smooth2(a, nx, ny):
    from scipy import signal

    kernel = np.ones((nx, ny)) * 1 / (nx * ny)
    r = signal.convolve2d(a, kernel, mode="same")
    return r




dso = xr.Dataset(
    {
        "curl_his": (
            [
                "lon",
                "lat",
            ],
            curl_his_ensemble,
        ),
        "curl_rcp": (
            [
                "lon",
                "lat",
            ],
            curl_rcp_ensemble,
        ),
    },
    coords={
        "lon": (["lon"], longi[:, 0]),
        "lat": (["lat"], lati[0, :]),
    },
)
curl_his_ensemble = smooth2(curl_his_ensemble, 8, 8)
curl_rcp_ensemble = smooth2(curl_rcp_ensemble, 8, 8)





dso = xr.Dataset(
    {
        "curl_his": (
            [
                "lon",
                "lat",
            ],
            curl_his_ensemble,
        ),
        "curl_rcp": (
            [
                "lon",
                "lat",
            ],
            curl_rcp_ensemble,
        ),
    },
    coords={
        "lon": (["lon"], longi[:, 0]),
        "lat": (["lat"], lati[0, :]),
    },
)
lon1 = 0
lon2 = 360
lat1 = -90
lat2 = 90
lon = dso.lon
lat = dso.lat
crt = (lon >= lon1) & (lon <= lon2) & (lat >= lat1) & (lat <= lat2)
curlh = dso.curl_his.where(crt, drop=True)
curlr = dso.curl_rcp.where(crt, drop=True)





filename ="data/ts_profile_allwbc.mat"
data = loadmat(filename)
for i in data.keys():
    locals()[i] = data[i]
z = np.squeeze(np.float16(dep_standard.copy()))

p = np.squeeze(gsw.p_from_z(-z, lat=22.5))
pthku = t_1950_ku_standard.copy()
ptrku = t_2050_ku_standard.copy()
shku = s_1950_ku_standard.copy()
srku = s_2050_ku_standard.copy()
cthku = gsw.CT_from_pt(shku, pthku)
ctrku = gsw.CT_from_pt(srku, ptrku)
x, y = cthku.shape
n2hku = np.zeros((x - 1, y))
n2rku = np.zeros((x - 1, y))
n2rsku = np.zeros((x - 1, y))
n2rtku = np.zeros((x - 1, y))
for i in range(8):
    n2hku[:, i], depthnh = gsw.Nsquared(shku[:, i], cthku[:, i], p)
    n2rku[:, i], depthnr = gsw.Nsquared(srku[:, i], ctrku[:, i], p, )
    n2rsku[:, i], temp = gsw.Nsquared(srku[:, i], cthku[:, i], p, )
    n2rtku[:, i], temp = gsw.Nsquared(shku[:, i], ctrku[:, i], p, )

pthgf = t_1950_gf_standard.copy()
ptrgf = t_2050_gf_standard.copy()
shgf = s_1950_gf_standard.copy()
srgf = s_2050_gf_standard.copy()
cthgf = gsw.CT_from_pt(shgf, pthgf)
ctrgf = gsw.CT_from_pt(srgf, ptrgf)
x, y = cthgf.shape
n2hgf = np.zeros((x - 1, y))
n2rgf = np.zeros((x - 1, y))
n2rsgf = np.zeros((x - 1, y))
n2rtgf = np.zeros((x - 1, y))
for i in range(8):
    n2hgf[:, i], depthnh = gsw.Nsquared(shgf[:, i], cthgf[:, i], p, )
    n2rgf[:, i], depthnr = gsw.Nsquared(srgf[:, i], ctrgf[:, i], p, )
    n2rsgf[:, i], temp = gsw.Nsquared(srgf[:, i], cthgf[:, i], p, )
    n2rtgf[:, i], temp = gsw.Nsquared(shgf[:, i], ctrgf[:, i], p, )

pthag = t_1950_ag_standard.copy()
ptrag = t_2050_ag_standard.copy()
shag = s_1950_ag_standard.copy()
srag = s_2050_ag_standard.copy()
cthag = gsw.CT_from_pt(shag, pthag)
ctrag = gsw.CT_from_pt(srag, ptrag)
x, y = cthag.shape
n2hag = np.zeros((x - 1, y))
n2rag = np.zeros((x - 1, y))
n2rsag = np.zeros((x - 1, y))
n2rtag = np.zeros((x - 1, y))
for i in range(8):
    n2hag[:, i], depthnh = gsw.Nsquared(shag[:, i], cthag[:, i], p, )
    n2rag[:, i], depthnr = gsw.Nsquared(srag[:, i], ctrag[:, i], p, )
    n2rsag[:, i], temp = gsw.Nsquared(srag[:, i], cthag[:, i], p, )
    n2rtag[:, i], temp = gsw.Nsquared(shag[:, i], ctrag[:, i], p, )

pthau = t_1950_au_standard.copy()
ptrau = t_2050_au_standard.copy()
shau = s_1950_au_standard.copy()
srau = s_2050_au_standard.copy()
cthau = gsw.CT_from_pt(shau, pthau)
ctrau = gsw.CT_from_pt(srau, ptrau)
x, y = cthau.shape
n2hau = np.zeros((x - 1, y))
n2rau = np.zeros((x - 1, y))
n2rsau = np.zeros((x - 1, y))
n2rtau = np.zeros((x - 1, y))
for i in range(8):
    n2hau[:, i], depthnh = gsw.Nsquared(shau[:, i], cthau[:, i], p, )
    n2rau[:, i], depthnr = gsw.Nsquared(srau[:, i], ctrau[:, i], p, )
    n2rsau[:, i], temp = gsw.Nsquared(srau[:, i], cthau[:, i], p, )
    n2rtau[:, i], temp = gsw.Nsquared(shau[:, i], ctrau[:, i], p, )

pthbz = t_1950_bz_standard.copy()
ptrbz = t_2050_bz_standard.copy()
shbz = s_1950_bz_standard.copy()
srbz = s_2050_bz_standard.copy()
cthbz = gsw.CT_from_pt(shbz, pthbz)
ctrbz = gsw.CT_from_pt(srbz, ptrbz)
x, y = cthbz.shape
n2hbz = np.zeros((x - 1, y))
n2rbz = np.zeros((x - 1, y))
n2rsbz = np.zeros((x - 1, y))
n2rtbz = np.zeros((x - 1, y))
for i in range(8):
    n2hbz[:, i], depthnh = gsw.Nsquared(shbz[:, i], cthbz[:, i], p, )
    n2rbz[:, i], depthnr = gsw.Nsquared(srbz[:, i], ctrbz[:, i], p, )
    n2rsbz[:, i], temp = gsw.Nsquared(srbz[:, i], cthbz[:, i], p, )
    n2rtbz[:, i], temp = gsw.Nsquared(shbz[:, i], ctrbz[:, i], p, )





n2hall = {}
n2rall = {}
n2rsall = {}
n2rtall = {}

n2hall.update({"ku": n2hku})
n2rall.update({"ku": n2rku})
n2rsall.update({"ku": n2rsku})
n2rtall.update({"ku": n2rtku})


n2hall.update({"gf": n2hgf})
n2rall.update({"gf": n2rgf})
n2rsall.update({"gf": n2rsgf})
n2rtall.update({"gf": n2rtgf})

n2hall.update({"ag": n2hag})
n2rall.update({"ag": n2rag})
n2rsall.update({"ag": n2rsag})
n2rtall.update({"ag": n2rtag})

n2hall.update({"au": n2hau})
n2rall.update({"au": n2rau})
n2rsall.update({"au": n2rsau})
n2rtall.update({"au": n2rtau})

n2hall.update({"bz": n2hbz})
n2rall.update({"bz": n2rbz})
n2rsall.update({"bz": n2rsbz})
n2rtall.update({"bz": n2rtbz})


# In[15]:


wbcs = ["ku", "gf", "ag", "au", "bz"]


# In[16]:


filename = "data/ts_profile.mat"
data = loadmat(filename)
for i in data.keys():
    locals()[i] = data[i]
pth = t_1950_ku_standard.copy()
ptr = t_2050_ku_standard.copy()
sh = s_1950_ku_standard.copy()
sr = s_2050_ku_standard.copy()
z = np.squeeze(np.float16(dep_standard.copy()))
x, y = cthku.shape
n2h = np.zeros((x - 1, y))
n2r = np.zeros((x - 1, y))
n2rs = np.zeros((x - 1, y))
n2rt = np.zeros((x - 1, y))


colors1 = [
    "#e41a1c",
    "#377eb8",
    "#4daf4a",
    "#984ea3",
    "#ff7f00",
    "#ffff33",
    "#a65628",
    "#f781bf",
    "#999999",
]




dsp = xr.open_dataset("data/dcurl_pv.nc")




pv = dsp.pv.where(crt, drop=True)
temp = curlh.values
temp[np.isnan(pv)] = np.nan
curlh.values = temp
temp = curlr.values
temp[np.isnan(pv)] = np.nan
curlr.values = temp





pvo = pv.values
pvo[pvo > 0.05] = np.nan
pvo[~np.isnan(pvo)] = 0.1





fig = plt.figure(figsize=(7 * 1.2, 6.5 * 1.2))
myproj = ccrs.LambertCylindrical(central_longitude=180)
ax1 = plt.subplot2grid((3, 2), (0, 0), rowspan=1, colspan=2, projection=myproj)
im1 = curlh.T.plot.contourf(
    ax=ax1,
    transform=ccrs.PlateCarree(),
    levels=np.arange(-2e-7, 2.1e-7, 0.25e-7),
    extend="both",
    add_colorbar=0,
    # cmap=newcmp,
)


ax2 = plt.subplot2grid((3, 2), (1, 0), rowspan=1, colspan=2, projection=myproj)
im2 = (curlr - curlh).T.plot.contourf(
    ax=ax2,
    transform=ccrs.PlateCarree(),
    levels=np.arange(-2e-8, 2.01e-8, 0.25e-8),
    extend="both",
    add_colorbar=0,
)

nx, ny = pv.shape
lonp = pv.lon.values
latp = pv.lat.values
Lon, Lat = np.meshgrid(lonp, latp)
xx1 = 8
yy1 = 6
Lon, Lat = np.meshgrid(lonp[::xx1], latp[::yy1])
ax2.scatter(
    Lon.T.reshape(-1),
    Lat.T.reshape(-1),
    pvo[::xx1, ::yy1].reshape(-1),
    transform=ccrs.PlateCarree(),
    c="k",
    # s=20
)


cbar2 = fig.colorbar(im2, ax=ax2, shrink=0.9, pad=0.02, format=formatter)
cbar2.ax.get_yaxis().get_offset_text().set_position((7, 1))
cbar2.set_label("$\Delta$WSC($m\ s^{-2}$)")
cbar2.set_ticks(np.arange(-2.0e-8, 2.1e-8, 0.5e-8))

ax2.add_feature(feature.LAND, color="gray", zorder=2)
ax2.coastlines(color="k", zorder=2, linewidths=0.8)

ax2.set_xticks(np.arange(0, 361, 60), crs=ccrs.PlateCarree())
ax2.set_yticks(np.arange(-60, 61, 30), crs=ccrs.PlateCarree())
lon_formatter = LongitudeFormatter(zero_direction_label=False)
lat_formatter = LatitudeFormatter()
ax2.xaxis.set_major_formatter(lon_formatter)
ax2.yaxis.set_major_formatter(lat_formatter)
ax2.set_xlabel("")
ax2.set_ylabel("")
ax2.set_title("b", loc="right", fontweight="bold", fontsize=13)

cbar1 = fig.colorbar(im1, ax=ax1, shrink=0.9, pad=0.02, format=formatter)
cbar1.ax.get_yaxis().get_offset_text().set_position((7, 1))
cbar1.set_ticks(np.arange(-2.0e-7, 2.11e-7, 0.5e-7))
cbar1.set_label("WSC($m\ s^{-2}$)")

ax1.add_feature(feature.LAND, color="gray", zorder=2)
ax1.coastlines(color="k", zorder=2, linewidths=0.8)

ax1.set_xticks(np.arange(0, 361, 60), crs=ccrs.PlateCarree())
ax1.set_yticks(np.arange(-60, 61, 30), crs=ccrs.PlateCarree())
lon_formatter = LongitudeFormatter(zero_direction_label=False)
lat_formatter = LatitudeFormatter()
ax1.xaxis.set_major_formatter(lon_formatter)
ax1.yaxis.set_major_formatter(lat_formatter)
ax1.set_xlabel("")
ax1.set_ylabel("")
ax1.set_title("a", loc="right", fontweight="bold", fontsize=13)

plt.tight_layout()
titles = ["c", "d", "e", "f", "g"]
titles1 = ["KC", "GS", "AC", "EAC", "BC"]
titles1 = ["NP", "NA", "SI", "SP", "SA"]

for i in range(5):
    wbc = wbcs[i]
    ax = plt.subplot2grid((10, 30), (7, i * 5), rowspan=2, colspan=5)

    n2r = n2rall[wbc]
    n2h = n2hall[wbc]
    n2rt = n2rtall[wbc]
    n2rs = n2rsall[wbc]

    pt = n2r - n2h
    tm = np.mean(pt, 1)
    # ts = np.std(pt, 1)
    ts = np.zeros((len(tm), 2))
    for ii in range(len(tm)):
        ts[ii, 0], ts[ii, 1] = bequ(pt[ii, :])

    ax.plot(tm, depthnh, color="k", zorder=10, label="Total")
    ax.fill_betweenx(depthnh, ts[:, 0], ts[:, 1], color="k", alpha=0.3)

    pt = n2rt - n2h
    tm = np.mean(pt, 1)
    # ts = np.std(pt, 1)
    ts = np.zeros((len(tm), 2))
    for ii in range(len(tm)):
        ts[ii, 0], ts[ii, 1] = bequ(pt[ii, :])
    ax.plot(tm, depthnh, color=colors1[0], zorder=9, label="$\Delta$T")
    ax.fill_betweenx(depthnh, ts[:, 0], ts[:, 1], color=colors1[0], alpha=0.3)
    ax.set_ylim(2000, 0)

    pt = n2rs - n2h
    tm = np.mean(pt, 1)
    # ts = np.std(pt, 1)
    ts = np.zeros((len(tm), 2))
    for ii in range(len(tm)):
        ts[ii, 0], ts[ii, 1] = bequ(pt[ii, :])
    ax.plot(tm, depthnh, color=colors1[1], zorder=8, label="$\Delta$S")
    ax.fill_betweenx(depthnh, ts[:, 0], ts[:, 1], color=colors1[1], alpha=0.3)
    ax.set_ylim(2000, 0)

    if i == 0:
        ax.axes.ticklabel_format(
            axis="y", style="sci", useMathText=True, scilimits=(-1, 1)
        )
        ax.set_ylabel("Depth(m)")
    else:
        ax.set_yticklabels("")

    if i == 2:
        ax.axes.ticklabel_format(
            axis="x", style="sci", useMathText=True, scilimits=(-1, 1)
        )
        ax.set_xlabel("$\Delta$N$^{2}$(s$^{-2}$)")
    else:
        ax.axes.ticklabel_format(
            axis="x", style="sci", useMathText=True, scilimits=(-1, 1)
        )
        ax.set_xlabel("")
    ax.set_title(titles[i], loc="right", fontweight="bold", fontsize=13)
    ax.set_title(titles1[i])
    ax.get_xaxis().get_offset_text().set_position((1.2, 0))

plt.legend(loc=(1.01, 0.25))
plt.savefig("FigureE1.pdf", bbox_inches="tight")







# In[ ]:




